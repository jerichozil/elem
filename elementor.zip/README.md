Elementor home assignment by Yoram Zilbershats.

Intro:

I am showing 2 different solutions to the assignment:
1. Rendering the 3 items in HTML (top).
2. Rendering the 3 items in JS which can handle lists of items making it API ready (bottom).


Instructions for deployment:

1. Request can be made to server side (/server/server.php) only with web server.
2. Point web server root directory to the root of this project.
3. Open index.html



Attached screen capture of the page.
